import { Injectable } from '@angular/core';
import { Router,CanActivate } from "@angular/router";

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate{

  constructor(private router:Router) { }

  canActivate(){

  var userdata = localStorage.getItem("Userdata");
  if(userdata == null || userdata == undefined || userdata == "")
  {

    this.router.navigate(['login']);
    return false;
  }

    return true;

  }

}

import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
@Injectable()
export class AuthServiceService implements CanActivate {

  constructor(public router: Router) { }

  canActivate(): boolean {
    const Userdata = localStorage.getItem('Userdata');
    // Check whether the token is expired and return
    // true or false
    if(Userdata == null || Userdata == undefined || Userdata == "")
    {
      console.log('Navigate to login');
      this.router.navigate(['login']);
      return false;
    }
    return true;
  }
}

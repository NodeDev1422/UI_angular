import { NgModule } from '@angular/core';
import { Routes, RouterModule,CanActivate } from '@angular/router';
import {  DashboardComponent } from './Admin/dashboard/dashboard.component';
import { WidgetsComponent } from "./Admin/widgets/widgets.component";
import{ LoginComponent } from "./Admin/login/login.component";
//import { AuthServiceService as AuthGuard } from "./Admin/services/auth-service.service";

import{ AuthGuardService  } from "./Admin/services/auth-guard.service";

const routes: Routes = [

  //before login
  { path:'', component: LoginComponent,pathMatch:'full' },
  { path:'login', component: LoginComponent},

  //after login
{ path:'dashboard', component: DashboardComponent,canActivate:[AuthGuardService]},
  { path:'widgets', component: WidgetsComponent,canActivate:[AuthGuardService]},
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
